package com.embergabor.simplex.core.player

import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.common.util.Util
import com.embergabor.simplex.core.plex.Stream

/** How the current file reaches the TV. VIDEO_CONVERTED: Plex chose to convert the video too, no subtitles. */
enum class Delivery { DIRECT, AUDIO_CONVERTED, VIDEO_CONVERTED, BURNING }

/** What actually goes out of the TV's audio output: a bitstream (passthrough) or decoded PCM. */
data class AudioOutput(val encoding: Int, val channels: Int)

/** What Plex's converted stream delivers, as ExoPlayer sees it. */
data class AudioInput(val mimeType: String?, val channels: Int)

/** The lines of the info box shown with the player controls. */
data class PlaybackInfo(val video: String, val audio: String, val subtitle: String, val markers: List<String>)

/** The box shown when the remote's audio or subtitle button switches tracks. */
data class TrackInfo(val heading: String, val lines: List<Pair<String, String>>, val markers: List<String>)

@OptIn(UnstableApi::class)
object Describe {

    /** [compat]: the compatibility track offered instead of converting [s] ([PlexTracks.AudioChoice.ASK]). */
    fun audioTrack(
        s: Stream,
        number: Int,
        count: Int,
        compat: Stream? = null,
        choice: PlexTracks.AudioChoice = PlexTracks.AudioChoice.PLAY,
    ) = TrackInfo(
        heading = "Audio $number of $count",
        lines = listOfNotNull(
            s.title?.let { "Title" to it },
            "Lang" to language(s),
            "Format" to audioFormat(s),
            listOfNotNull(
                s.channelLayout,
                s.samplingRate?.let { "${kHz(it)} kHz" },
                s.bitrate?.let { "$it kbps" },
            ).takeIf { it.isNotEmpty() }?.let { "Detail" to it.joinToString(" · ") },
            compat?.let { "Choice" to "${audioFormat(it)} compatibility track, or Plex converts" },
        ),
        markers = listOfNotNull(
            "Default".takeIf { s.isDefault },
            "Plex converts".takeIf { choice == PlexTracks.AudioChoice.CONVERT },
        ),
    )

    /** [s] null: subtitles off. */
    fun subtitleTrack(s: Stream?, number: Int, count: Int) = if (s == null) {
        TrackInfo("Subtitles off", emptyList(), emptyList())
    } else TrackInfo(
        heading = "Subtitles $number of $count",
        lines = listOfNotNull(
            s.title?.let { "Title" to it },
            "Lang" to language(s),
            "Format" to subtitleCodec(s.codec) + if (s.isExternal) " · separate file" else "",
        ),
        markers = listOfNotNull(
            "Default".takeIf { s.isDefault },
            "Forced".takeIf { s.forced },
            "SDH".takeIf { s.hearingImpaired },
        ),
    )

    /** The language in English ("Japanese"), from the ISO code when there is one, else Plex's name. */
    fun language(s: Stream): String {
        val fromCode = s.languageCode?.let { java.util.Locale.forLanguageTag(it).getDisplayLanguage(java.util.Locale.ENGLISH) }
        return fromCode?.takeIf { it.isNotBlank() && !it.equals(s.languageCode, ignoreCase = true) }
            ?: s.language ?: s.languageCode ?: "Unknown"
    }

    /**
     * A track's own title when it says something the language and format don't ("Commentary", "SDH"):
     * titles that only repeat codec, channels or bitrate ("DTS-HD Master Audio / 2.0 / 48 kHz", "Surround
     * 5.1", "Magyar AC3 2.0 192 kbps") are left out.
     */
    fun ownTitle(s: Stream): String? {
        val t = s.title?.trim()?.takeIf { it.isNotEmpty() } ?: return null
        val technical = Regex(
            "\\d\\.\\d|kbps|khz|\\b(ac-?3|e-?ac-?3|dts|truehd|dolby|aac|flac|pcm|lpcm|atmos|opus|mp3|stereo|mono|surround|" +
                "pgs|srt|ass|vobsub|subrip|compat)\\b",
            RegexOption.IGNORE_CASE,
        )
        if (technical.containsMatchIn(t)) return null
        if (t.equals(language(s), ignoreCase = true) || t.equals(s.language, ignoreCase = true)) return null
        return t
    }

    /** The label on the player's Audio and Subtitles buttons: "Japanese · DTS-HD MA Stereo", "English · PGS". */
    fun trackLabel(s: Stream): String {
        val format = if (s.streamType == 3) subtitleCodec(s.codec) else audioFormat(s)
        return listOfNotNull(language(s), format, ownTitle(s), "Forced".takeIf { s.streamType == 3 && s.forced })
            .joinToString(" · ")
    }

    fun audioFormat(s: Stream): String {
        val atmos = if (s.displayTitle.contains("Atmos", ignoreCase = true)) " Atmos" else ""
        return "${codecName(s.codec, s.profile)} ${s.channels?.let(::channels) ?: ""}".trim() + atmos
    }

    private fun kHz(rate: Int) = if (rate % 1000 == 0) "${rate / 1000}" else "%.1f".format(java.util.Locale.ROOT, rate / 1000f)

    fun info(
        video: Stream?,
        audio: Stream?,
        subtitle: Stream?,
        delivery: Delivery,
        input: AudioInput?,
        output: AudioOutput?,
    ) = PlaybackInfo(
        video = video(video),
        audio = audio(audio, delivery, input, output),
        subtitle = subtitle?.let { subtitleCodec(it.codec) } ?: "Off",
        markers = when (delivery) {
            Delivery.DIRECT -> listOf("Direct play")
            Delivery.AUDIO_CONVERTED -> listOf("Audio transcode")
            Delivery.VIDEO_CONVERTED -> listOf("Audio transcode", "Video transcode")
            Delivery.BURNING -> listOf("Audio transcode", "Video transcode", "Subtitles burned in")
        },
    )

    fun video(s: Stream?): String {
        if (s == null) return "—"
        val range = when {
            s.doviProfile != null -> if (s.doviProfile > 0) "Dolby Vision P${s.doviProfile}" else "Dolby Vision"
            s.colorTrc == "smpte2084" -> "HDR10"
            s.colorTrc == "arib-std-b67" -> "HLG"
            else -> "SDR"
        }
        return listOfNotNull(
            videoCodecName(s.codec),
            if (s.width != null && s.height != null) "${s.width}×${s.height}${scan(s.scanType)}" else null,
            s.frameRate?.let { "${fps(it)} fps" },
            range,
        ).joinToString(" · ")
    }

    fun audio(s: Stream?, delivery: Delivery, input: AudioInput?, output: AudioOutput?): String {
        if (s == null) return "—"
        val source = audioFormat(s)
        val converted = if (delivery != Delivery.DIRECT && input != null) {
            " → Plex ${mimeName(input.mimeType)} ${channels(input.channels)}"
        } else ""
        val out = when {
            output == null -> ""
            Util.isEncodingLinearPcm(output.encoding) -> " → decoded, PCM ${channels(output.channels)}"
            // Plex's conversion already names its format; the file's own audio says what the TV got.
            delivery != Delivery.DIRECT -> " → passthrough"
            else -> " → passthrough" + (passthroughName(output.encoding)?.let { " as $it" } ?: "")
        }
        return source + converted + out
    }

    /** What the TV is handed as a bitstream: shows whether DTS-HD went out whole or as its DTS core. */
    private fun passthroughName(encoding: Int) = when (encoding) {
        C.ENCODING_AC3 -> "AC3"
        C.ENCODING_E_AC3, C.ENCODING_E_AC3_JOC -> "E-AC3"
        C.ENCODING_DTS -> "DTS"
        C.ENCODING_DTS_HD -> "DTS-HD"
        C.ENCODING_DOLBY_TRUEHD -> "TrueHD"
        else -> null
    }

    private fun scan(type: String?) = when (type?.lowercase()) {
        "progressive" -> "p"
        "interlaced" -> "i"
        else -> ""
    }

    fun codecName(codec: String?, profile: String? = null): String = when (codec?.lowercase()) {
        "truehd" -> "TrueHD"
        "eac3" -> "E-AC3"
        "ac3" -> "AC3"
        "dca-ma" -> "DTS-HD MA"
        "dca", "dts" -> when (profile?.lowercase()) {
            "ma" -> "DTS-HD MA"
            "hra" -> "DTS-HD HRA"
            else -> "DTS"
        }
        "aac" -> "AAC"
        "flac" -> "FLAC"
        "mp3" -> "MP3"
        "opus" -> "Opus"
        "vorbis" -> "Vorbis"
        null -> "?"
        else -> if (codec.startsWith("pcm")) "PCM" else codec.uppercase()
    }

    fun videoCodecName(codec: String?): String = when (codec?.lowercase()) {
        "h264", "avc" -> "H.264"
        "hevc", "h265" -> "HEVC"
        "mpeg2video" -> "MPEG-2"
        "mpeg1video" -> "MPEG-1"
        "vc1" -> "VC-1"
        "wmv3", "wmv2", "wmv1" -> "WMV"
        "mpeg4" -> "MPEG-4"
        "msmpeg4v3", "msmpeg4v2" -> "DivX 3"
        "av1" -> "AV1"
        "vp9" -> "VP9"
        "vp8" -> "VP8"
        null -> "?"
        else -> codec.uppercase()
    }

    fun subtitleCodec(codec: String?): String = when (codec?.lowercase()) {
        "srt", "subrip" -> "SRT"
        "ass", "ssa" -> "ASS"
        "pgs", "hdmv_pgs_subtitle" -> "PGS"
        "vobsub", "dvd_subtitle" -> "VobSub"
        "mov_text", "tx3g" -> "MP4 text"
        "webvtt", "vtt" -> "WebVTT"
        null -> "?"
        else -> codec.uppercase()
    }

    fun channels(n: Int): String = when (n) {
        1 -> "Mono"
        2 -> "Stereo"
        6 -> "5.1"
        8 -> "7.1"
        else -> "${n}ch"
    }

    private fun mimeName(mime: String?) = when (mime) {
        MimeTypes.AUDIO_E_AC3, MimeTypes.AUDIO_E_AC3_JOC -> "E-AC3"
        MimeTypes.AUDIO_AC3 -> "AC3"
        MimeTypes.AUDIO_AAC -> "AAC"
        else -> mime?.substringAfter('/')?.uppercase() ?: "?"
    }

    private fun fps(f: Float): String = when {
        kotlin.math.abs(f - 23.976f) < 0.01f -> "23.976"
        kotlin.math.abs(f - 29.97f) < 0.01f -> "29.97"
        kotlin.math.abs(f - 59.94f) < 0.01f -> "59.94"
        f % 1f == 0f -> f.toInt().toString()
        else -> "%.3f".format(f).trimEnd('0').trimEnd('.')
    }

    /** Channel count from an Android channel mask (AudioFormat.CHANNEL_OUT_*). */
    fun channelCount(mask: Int) = Integer.bitCount(mask)
}
